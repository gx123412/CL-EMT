from datetime import datetime
import time


start_time = datetime.now()
print("the current time: ", start_time)


import subprocess

commands = [
    'python main_pretrain.py --training-fold 0 --gpu-index 0 --dataset both --cls 9 >0.out ',
    'python main_pretrain.py --training-fold 1 --gpu-index 0 --dataset both --cls 9 >1.out',
    'python main_pretrain.py --training-fold 2 --gpu-index 0 --dataset both --cls 9 >2.out ',
    'python main_pretrain.py --training-fold 3 --gpu-index 0 --dataset both --cls 9 >3.out',
    'python main_pretrain.py --training-fold 4 --gpu-index 0 --dataset both --cls 9 >4.out ',
    'python main_pretrain.py --training-fold 5 --gpu-index 0 --dataset both --cls 9 >5.out',
    'python main_pretrain.py --training-fold 6 --gpu-index 0 --dataset both --cls 9 >6.out ',
    'python main_pretrain.py --training-fold 7 --gpu-index 0 --dataset both --cls 9 >7.out',
    'python main_pretrain.py --training-fold 8 --gpu-index 0 --dataset both --cls 9 >8.out ',
    'python main_pretrain.py --training-fold 9 --gpu-index 0 --dataset both --cls 9 >9.out',
    # Add more commands as needed
]

processes = []
for i in range(0,10,2):
    for j in range(i,i+2,1):
        command=commands[j]
        process = subprocess.Popen(command, shell=True)
        processes.append(process)
        print('Run the command:', command)
        # 让程序等待1秒
        time.sleep(1)

    # Wait for all processes to finish
    for process in processes:
        process.wait()

    print("###########################################################################################")







cmds = [
    'python extract_pretrainFeat.py --dataset both --cls 2 >10.out',
    'python running_norm.py --dataset both --cls 2 >11.out',
    'python smooth_lds.py --dataset both --cls 2  >12.out',
    'python main_classify.py --dataset both --cls 2 >13.out',
    'python main_classify.py --train-or-test test --dataset both --cls 2 >14.out',
    'python main_classify.py --val-method loo --dataset both --cls 2 >15.out',
    'python main_classify.py --train-or-test test --val-method loo --dataset both --cls 2 >16.out',


    'python extract_pretrainFeat.py --dataset both --cls 9 >30.out',
    'python running_norm.py --dataset both --cls 9 >31.out',
    'python smooth_lds.py --dataset both --cls 9  >32.out',
    'python main_classify.py --dataset both --cls 9 >33.out',
    'python main_classify.py --train-or-test test --dataset both --cls 9 >34.out',
    'python main_classify.py --val-method loo --dataset both --cls 9 >35.out',
    'python main_classify.py --train-or-test test --val-method loo --dataset both --cls 9 >36.out',
    # Add more commands as needed



    'python extract_pretrainFeat.py --dataset both --cls 9 >130.out',
    'python running_norm.py --dataset both --cls 9 >131.out',
    'python smooth_lds.py --dataset both --cls 9  >132.out',
    'python main_classify.py --dataset both --cls 9 >133.out',
    'python main_classify.py --train-or-test test --dataset both --use-data raw --cls 9 >134.out',
    'python main_classify.py --val-method loo --dataset both --cls 9 >135.out',
    'python main_classify.py --train-or-test test --val-method loo --dataset both --cls 9 >136.out',
    # Add more commands as needed



]

processes1 = []
for cmd in cmds:
    process1 = subprocess.Popen(cmd, shell=True)
    processes1.append(process1)
    print(cmd)
    for process1 in processes1:
        process1.wait()

end_time = datetime.now()
print("total time consumed:", end_time - start_time)
print("the current time ：", datetime.now())